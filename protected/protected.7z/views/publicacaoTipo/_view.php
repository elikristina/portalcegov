	<?php echo CHtml::link(CHtml::encode($data->nome), array('update', 'id'=>$data->cod_tipo), array('class'=>'button')); ?>
	<br>

