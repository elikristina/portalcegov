<div class="row-fluid">
	<div class="span12">
		<h1><?php echo CHtml::encode($title);?></h1>
		<div class="form">
		
		<?php $form=$this->beginWidget('CActiveForm', array(
			'id'=>'pagina-form',
			'enableAjaxValidation'=>false,
		));
		
		Yii::app()->clientScript->registerScript('text-areas',"
				tinyMCE.init({
										mode : 'textareas',
										theme : 'advanced',
										width: '100%',
		        						height: '300',
		        						relative_urls : false,
									file_browser_callback : 'filebrowser',	
									});
			");
		
		 ?>
		
			
				<?php echo CHtml::textArea("Pagina[conteudo]", $content); ?>
			
		
			<div class="row-buttons">
				<?php echo CHtml::button('Cancelar', array('submit' => array('/about/index'), 'class'=>'btn btn-small btn-primary')); ?>
				<?php echo CHtml::submitButton('Salvar', array('class'=>'btn btn-small btn-primary')); ?>
			</div>
		
			
		
		<?php $this->endWidget(); ?>
		
		</div><!-- form -->
	</div><!--span-->
</div><!-- row -->