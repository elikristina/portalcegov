<?php $this->beginContent('//layouts/main'); ?>
<div class="container-fluid">
      <div class="row-fluid">
        <div class="span12 default-container">
		<?php echo $content; ?>
		</div><!-- /span -->
	  </div><!-- /row -->
</div> <!-- /span -->
<?php $this->endContent(); ?>