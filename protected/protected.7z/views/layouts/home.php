<?php $this->beginContent('//layouts/main'); ?>
<div class="container">
	<?php echo $content; ?>
</div>
<?php $this->endContent(); ?>
