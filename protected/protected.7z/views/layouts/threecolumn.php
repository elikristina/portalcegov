<?php 
/**
 * Layout da página de publicações.
 */

Yii::app()->clientScript->registerScript('carousel', "

$('.carousel').carousel({
  interval: false,
  
}).bind('slid', function()
	{
		$('.widget-carousel-text').jScrollPane();
	});


");

//Registra os scripts para o scroll
$baseUrl = Yii::app()->request->baseUrl;
Yii::app()->clientScript->registerScriptFile($baseUrl ."/jScrollPane/jquery.jscrollpane.min.js");
Yii::app()->clientScript->registerScriptFile($baseUrl ."/jScrollPane/jquery.mousewheel.js");
Yii::app()->clientScript->registerScriptFile($baseUrl ."/jScrollPane/mwheelIntent.js");
Yii::app()->clientScript->registerCssFile($baseUrl ."/jScrollPane/jquery.jscrollpane.css");

Yii::app()->clientScript->registerScript("scroll", "
	$(function()
	{
		$('.scroll').jScrollPane();
		$('.widget-carousel-text').jScrollPane()
	});
");


?>

<?php $this->beginContent('//layouts/main'); ?>
<div class="container-fluid">


	<div class="row-fluid">
	
        <div class="span12 default-container">
        <?php echo $content?>
		</div><!-- /span -->
	</div>
	<div class="row-fluid">
	 
	 
	<div class="span4">
		<div class="widget-news">
			<h4><?php echo Yii::t('default', 'noticias')?></h4>
			<div class="widget-news-text scroll">
				<div id="pubs">
					<?php $news = Noticia::model()->findAll(array('order'=>'cod_noticia DESC, titulo', 'condition'=>'eh_evento=false', 'limit'=>10))?>
					<?php foreach($news as $new):?>
						<div class="pub-list" >
							<?php echo CHtml::link($new->titulo, array('/new/view', 'id'=>$new->cod_noticia));?>
						</div>
					<?php endforeach;?>
				</div>
			</div><!-- /widget-news- -->
			<div class="widget-news-button">
				<?php echo CHtml::link(Yii::t('default', 'mais') .' ' .Yii::t('default', 'noticias'), array('/new'), array('class'=>'button'))?>
			</div>
		</div><!-- /widget-news -->
   </div> <!--  /span4 -->
   
      <div class="span4">
		<div class="widget-news">
			<h4><?php echo Yii::t('default', 'eventos')?></h4>
			<div class="widget-news-text scroll">
				<div id="pubs">
					<?php $eventos = Noticia::model()->findAll(array('order'=>'cod_noticia DESC, titulo', 'condition'=>'eh_evento=true', 'limit'=>10))?>
					<?php foreach($eventos as $event):?>
						<div class="pub-list" >
							<?php echo CHtml::link($event->titulo, array('/new/view', 'id'=>$event->cod_noticia));?>
						</div>
					<?php endforeach;?>
				</div>
			</div><!-- /widget-news- -->
			<div class="widget-news-button">
				<?php echo CHtml::link(Yii::t('default', 'mais') .' ' .Yii::t('default', 'eventos'), array('/new/events'), array('class'=>'button'))?>
			</div>
		</div><!-- /widget-news -->
   </div> <!--  /span4 -->
   
   
	<div class="span4">
		<div class="widget-news">
			<h4><?php echo Yii::t('default', 'publicacoes')?></h4>
			<div class="widget-news-text scroll">
				<div id="pubs">
					<?php $pubs = Publicacao::model()->findAll(array('order'=>'titulo','condition'=>'pessoal=false' , 'limit'=>10))?>
					<?php foreach($pubs as $pub):?>
						<div class="pub-list" >
							<?php echo CHtml::link($pub->titulo, array('/publicacao/view', 'id'=>$pub->cod_publicacao));?>
						</div>
					<?php endforeach;?>
				</div>
			</div><!-- widget-text-->
			<div class="widget-news-button">
				<?php echo CHtml::link(Yii::t('default', 'mais') .' ' .Yii::t('default', 'publicacoes'), array('/publicacao'), array('class'=>'button'))?>
			</div>
		</div><!-- /widget-news -->
   </div> <!--  /span4 -->
   
</div><!-- /row -->
</div> <!-- /container -->
<?php $this->endContent(); ?>
