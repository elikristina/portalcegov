<?php
$this->breadcrumbs=array(
	'Equipe'=>array('index'),
	'Adicionar Membro',
);



$this->menu=array(
	array('label'=>'<i class="icon-list"></i> Listar Pessoas', 'url'=>array('index')),
	array('label'=>'<i class="icon-tasks"></i> Gerenciar Pessoas', 'url'=>array('admin')),
);
?>

<div class="row-fluid">
<div class="span10">
<h3>Adicionar Membro</h3>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>

</div>
</div>
