<?php
/* @var $this NewController */
/* @var $model Noticia */

$this->breadcrumbs=array(
	'Noticias'=>array('index'),
	'Adicionar',
);

$this->menu=array(
	array('label'=>'<i class="icon-list"></i> Listar Notícias', 'url'=>array('index')),
	array('label'=>'<i class="icon-list"></i> Listar Eventos', 'url'=>array('events')),
	array('label'=>'<i class="icon-tasks"></i> Gerenciar Notícias/Eventos', 'url'=>array('admin')),
);
?>

<h2>Adicionar Notícia</h2>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>