<?php
/* @var $this NewController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Notícias',
);

if (Yii::app()->user->name == 'admin') {
	$this->menu=array(
		array('label'=>'<i class="icon-plus"></i> Adicionar Notícia/Evento', 'url'=>array('create')),
		array('label'=>'<i class="icon-tasks"></i> Gerenciar Notícias/Eventos', 'url'=>array('admin')),
	);
}
?>

<h1><?php echo Yii::t('default','noticias')?></h1>

<div class="container-pub">
<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
</div>
