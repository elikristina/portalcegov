<?php
/* @var $this NewController */
/* @var $model Noticia */
/* @var $form CActiveForm */

Yii::app()->clientScript->registerScript('text-areas',"
		
	$('#form-tab a:first').tab('show');
  
	$('#tab-pt').click(function (e) {
	  	e.preventDefault();
	  	$('#form-pt').tab('show');
							
	});
	
	$('#tab-en').click(function (e) {
	  	e.preventDefault();
	  	$('#form-en').tab('show');
	});

	tinyMCE.init({
		mode : 'textareas',
		theme : 'advanced',
		width: '100%',
        height: '450',
        relative_urls : false,
        file_browser_callback : 'filebrowser',
	});
	
");
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'noticia-form',
	'enableAjaxValidation'=>false,
	 'htmlOptions'=>array('class'=>'form-vertical')
)); ?>

	<p class="note">Campos com <span class="required">*</span> são obrigatórios.</p>

		<?php echo $form->errorSummary($model); ?>
		
		
	<ul class="nav nav-tabs" id="form-tab">
	  <li><a id="tab-pt" data-target="#form-pt" data-toggle="tab">Português</a></li>
	  <li><a id="tab-en" data-target="#form-en" data-toggle="tab">English</a></li>
	</ul>
	
	<div class="tab-content">
		<div class="tab-pane active" id="form-pt">
			<div class="control-group input-large">
				<?php echo $form->labelEx($model,'titulo', array('class'=>'control-label')); ?>
				<?php echo $form->textField($model,'titulo', array('class'=>'input-xxlarge')); ?>
				<?php echo $form->error($model,'titulo'); ?>
			</div>
			<div class="control-group">
				<?php echo $form->labelEx($model,'texto', array('class'=>'control-label')); ?>
				<?php echo $form->textArea($model,'texto',array('rows'=>6, 'cols'=>50)); ?>
				<?php echo $form->error($model,'texto'); ?>
			</div>	
		</div>
		
		<div class="tab-pane" id="form-en">
			<div class="control-group input-large">
				<?php echo $form->labelEx($model,'titulo', array('class'=>'control-label')); ?>
				<?php echo $form->textField($model,'titulo_en', array('class'=>'input-xxlarge')); ?>
				<?php echo $form->error($model,'titulo_en'); ?>
			</div>
			<div class="control-group">
				<?php echo $form->labelEx($model,'texto', array('class'=>'control-label')); ?>
				<?php echo $form->textArea($model,'texto_en',array('rows'=>6, 'cols'=>50)); ?>
				<?php echo $form->error($model,'texto_en'); ?>
			</div>
		</div>
	</div>
		<div class="control-group">
			<?php echo $form->labelEx($model,'eh_evento', array('class'=>'control-label')); ?>
			<?php echo $form->checkBox($model,'eh_evento'); ?>
			<span class="help-block">Marque se esta notícia é um evento.</span>
			<?php echo $form->error($model,'eh_evento'); ?>
		</div>
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Criar' : 'Salvar', array('class'=>'btn btn-small btn-primary')); ?>

<?php $this->endWidget(); ?>

</div><!-- form -->