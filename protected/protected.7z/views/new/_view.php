<?php
/* @var $this NewController */
/* @var $data Noticia */

?>

<div class="row-fluid">
<div class="span12">

	<h4><?php echo CHtml::encode($data->t('titulo')); ?></h4>

	
	<div class="well well-small">
	<div class="news-text">
	<i class="pull-right"><?php echo CHtml::encode($data->data_postagem); ?></i><br>
	
	<?php echo $data->t('texto'); ?>
	
	<br />
	<!-- <div class="clearfix"></div>
	<?php if(!Yii::app()->user->isGuest):?>
		<br>
		<i class="pull-right">
		<?php if($data->eh_evento):?>
		Evento cadastrado por <b><?php echo CHtml::encode($data->autor); ?></b>
		<?php else:?>
		Notícia cadastrada por <b><?php echo CHtml::encode($data->autor); ?></b>
		<?php endif;?>
		</i>
		<div class="clearfix"></div>
	<?php endif;?>
	</div> -->
	
	<?php echo CHtml::link(Yii::t('default','detalhes'), array('/new/view', 'id'=>$data->cod_noticia), array('class'=>'btn btn-small btn-info pull-right'));?>
	<div class="clearfix"></div>
	</div>

</div><!-- span12 -->
</div><!-- row-fluid -->