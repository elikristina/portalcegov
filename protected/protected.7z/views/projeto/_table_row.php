<tr>
	<td><?php echo CHtml::link(CHtml::encode($data->nome), array('/projeto/view', 'id'=>$data->cod_projeto)); ?></td>
	<td><?php echo CHtml::link(CHtml::encode($data->gt->nome), array('/gt/view', 'id'=>$data->gt->cod_gt))?></td>
</tr>
