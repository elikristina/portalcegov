<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'grupo-trabalho-form',
	'enableAjaxValidation'=>false,
));

Yii::app()->clientScript->registerScript('tabs', "
	$(function () {
	
	$('#form-tab a:first').tab('show');
  
	$('#tab-pt').click(function (e) {
	  	e.preventDefault();
	  	$('#form-pt').tab('show');
							
	})
	
	$('#tab-en').click(function (e) {
	  	e.preventDefault();
	  	$('#form-en').tab('show');
	})    
    
    tinyMCE.init({
								mode : 'textareas',
								theme : 'advanced',
								width: '70%',
        						height: '250'
							});
  });
  
");

?>

	<p class="note">Campos com <span class="required">*</span> são obrigatórios.</p>

	<?php echo $form->errorSummary($model); ?>
	
	<ul class="nav nav-tabs" id="form-tab">
  		<li><a id="tab-pt" data-target="#form-pt" data-toggle="tab">Português</a></li>
  		<li><a id="tab-en" data-target="#form-en" data-toggle="tab">English</a></li>
	</ul>
	
	<div class="tab-content">
		<div class="tab-pane active" id="form-pt">
			<div class="row">
				<?php echo $form->labelEx($model,'nome'); ?>
				<?php echo $form->textField($model,'nome'); ?>
				<?php echo $form->error($model,'nome'); ?>
			</div>
			
			<div class="row">
				<?php echo $form->labelEx($model,'apresentacao'); ?>
				<?php // $this->widget('application.extensions.tinymce.ETinyMce', array('htmlOptions'=>array('cols'=>40, 'rows'=>80),'name'=>'GrupoTrabalho[apresentacao]','editorTemplate'=>'full',  'value'=>$model->apresentacao)); ?>
				<?php echo $form->textArea($model, 'apresentacao')?>
				<?php echo $form->error($model,'apresentacao'); ?>
			</div>
		</div>
		
		<div class="tab-pane" id="form-en">
			<div class="row">
				<?php echo $form->labelEx($model,'nome'); ?>
				<?php echo $form->textField($model,'nome_en'); ?>
				<?php echo $form->error($model,'nome_en'); ?>
			</div>
			
			<div class="row">
				<?php echo $form->labelEx($model,'apresentacao'); ?>
				<?php //$this->widget('application.extensions.tinymce.ETinyMce', array('htmlOptions'=>array('cols'=>40, 'rows'=>80),'name'=>'GrupoTrabalho[apresentacao]','editorTemplate'=>'full',  'value'=>$model->apresentacao_en)); ?>
				<?php echo $form->textArea($model, 'apresentacao_en')?>
				<?php echo $form->error($model,'apresentacao_en'); ?>
			</div>
		</div>
	</div>
	 <div class="row">
        <?php echo $form->labelEx($model,'visible'); ?>
        <?php echo $form->checkBox($model,'visible'); ?>
        <?php echo $form->error($model,'visible'); ?>
    </div>

	<div class="row">
		<?php echo $form->labelEx($model,'cod_coordenador'); ?>
		<?php  echo $form->dropDownList($model,'cod_coordenador', CHtml::listData(Pessoa::model()->findAll(array('order'=>'nome')), 'cod_pessoa', 'nome'), array('prompt'=>"Selecione um Coordenador")); ?>
		<?php echo $form->error($model,'cod_coordenador'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($model,'cod_pos_responsavel'); ?>
		<?php  echo $form->dropDownList($model,'cod_pos_responsavel', CHtml::listData(Pessoa::model()->findAll(array('order'=>'nome')), 'cod_pessoa', 'nome'), array('prompt'=>"Pós-Graduando Responsável")); ?>
		<?php echo $form->error($model,'cod_pos_responsavel'); ?>
	</div>
	<hr>
	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Adicionar' : 'Salvar', array('class'=>'btn btn-small btn-primary')); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->