<?php
$this->breadcrumbs=array(
	Yii::t('default', 'gts')=>array('index'),
	$model->t('nome'),
);

if (Yii::app()->user->name == 'admin') {
	$this->menu=array(
		array('label'=>'<i class="icon-list"></i> Listar GTs', 'url'=>array('index')),
		array('label'=>'<i class="icon-plus"></i> Adicionar GT', 'url'=>array('create')),
		array('label'=>'<i class="icon-tasks"></i> Gerenciar GTs', 'url'=>array('admin')),
		array('label'=>'<i class="icon-pencil"></i> Editar GT', 'url'=>array('update', 'id'=>$model->cod_gt)),
		array('label'=>'<i class="icon-plus"></i> Adicionar Projeto', 'url'=>array('createProjeto', 'id'=>$model->cod_gt)),
		array('label'=>'<i class="icon-tasks"></i> Gerenciar Projetos', 'url'=>array('adminProjeto', 'id'=>$model->cod_gt)),
		array('label'=>'<i class="icon-trash"></i> Deletar', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->cod_gt),'confirm'=>'Tem certeza que deseja deletar este GT?')),
	);
}
?>

<div class="row-fluid">
<div class="span12 view-gt">
	<h4><b>GT <?php echo CHtml::encode($model->t('nome')); ?></b></h4>
	
		<p>
		<b><?php echo CHtml::encode($model->getAttributeLabel('cod_coordenador')); ?>:</b>
		<?php echo CHtml::link(CHtml::encode($model->coordenador->nome), array('/pessoa/view', 'id'=>$model->coordenador->cod_pessoa)	); ?>
		<br />
		<?php if(isset($model->pos_responsavel)):?>
		<b><?php echo CHtml::encode($model->getAttributeLabel('cod_pos_responsavel')); ?>:</b>
		<?php echo CHtml::link(CHtml::encode($model->pos_responsavel->nome), array('/pessoa/view', 'id'=>$model->pos_responsavel->cod_pessoa)	); ?>
		<br />
		<?php endif;?>
		</p>
		<?php echo $model->t('apresentacao'); ?>
			
	<?php if(count($model->pessoas) > 0):?>
		<hr>
		<h5><b><?php echo Yii::t('GrupoTrabalho', 'participantes')?></b></h5>
			<ul class="ul-list-item">
			<?php foreach($model->pessoas as $p):?>
				<?php //echo CHtml::link(CHtml::encode($p->nome), array('/pessoa/view', 'id'=>$p->cod_pessoa), array('class'=>'link'));?>
				<?php $this->renderPartial('/pessoa/_pessoa-min', array('data'=>$p))?>
			<?php endforeach;?>
			</ul>
	<?php endif;?>
	
	<?php if(count($model->projetos) > 0):?>
		<hr>
		<h5><b>Projetos</b></h5>
			<?php foreach($model->projetos as $proj):?>
				<?php echo CHtml::link(CHtml::encode($proj->t('nome')), array('/gt/viewProjeto', 'id'=>$proj->cod_projeto));?><br>
			<?php endforeach;?>
	<?php endif;?>
</div><!-- span -->
</div><!-- row -->